/*
 * @Author: CsVeryLoveXieWenLi
 * @Description: 本地对局
 * @Copyright (c) 2026 by CsVeryLoveXieWenLi, All Rights Reserved.
 */
const game_msg = document.getElementById('game_msg');
const game_icon = document.getElementById('game_icon');


const main_app = document.getElementById('main_app');
const main_opt = document.getElementById('main_opt');
const main_game = document.getElementById('main_game');


const game_p1_name = document.getElementById('game_p1_name');


const select_server_balance = document.getElementById('select_server_balance');
const select_server_mode = document.getElementById('select_server_mode');
const select_server_first = document.getElementById('select_server_first');
const select_server_color = document.getElementById('select_server_color');

const select_server_level = document.getElementById('select_server_level');
const select_server_ai = document.getElementById('select_server_ai');

const input_server_archive = document.getElementById('input_server_archive');
const input_server_health = document.getElementById('input_server_health');
const input_server_board = document.getElementById('input_server_board');

const button_server_join = document.getElementById('button_server_join');
const button_server_test = document.getElementById('button_server_test');


const dialog_tools = document.getElementById('dialog_tools');

const button_tools_restart = document.getElementById('button_tools_restart');
const button_tools_archive = document.getElementById('button_tools_archive');

const details_tools_observers = document.getElementById('details_tools_observers');
const details_tools_names = document.getElementById('details_tools_names');


const button_home = document.getElementById('button_home');


const ArchiveV0 = window.FAscendExports.ArchiveV0;

const GameMessage = window.GameExports.Message;
const GameClient = window.GameExports.Client;
const GameTimer = window.GameExports.Timer;
const GameCanvas = window.GameExports.Canvas;
const GameSound = window.GameExports.Sound;

const Ai = window.MainExports.Ai;
const ShToast = window.UiExports.ShToast;
const BaseZalgo = window.UtilsExports.BaseZalgo;

const toast = new ShToast();




let is_main = true;




/**
 * @description: 转换
 * @param {number} x
 * @param {number} y
 * @param {number} width
 * @return {number}
 */
const xy2index = (x, y, width) => {
    return y * width + x;
};
/**
 * @description: 转换
 * @param {number} index
 * @param {number} width
 * @return {[number, number]}
 */
const index2xy = (index, width) => {
    const y = Math.floor(index / width);
    const x = index % width;
    return [x, y];
};




/**
 * @description: 测试AI的推理速度
 * @param {string} name
 * @param {number} opt
 * @return {void}
 */
const ai_test = async (name, opt, synchronizeRandom = false) => {
    try {
        await window.ai_worker.AI_INIT();

        if (name === '4ascend-zero') {
            await ai_worker.ZERO_RESET(
                Math.floor(Date.now() / 1000) >>> 0,
                (Math.floor(Date.now() / 1000) ^ crypto.getRandomValues(new Uint32Array(1))[0]) >>> 0,
                0,
                6,
                select_server_mode.value === 'normal',
            );
            await ai_worker.ZERO_TURN(xy2index(4, 4, 9));

            const st = Math.round(performance.now() * 1000);
            await ai_worker.ZERO_THINK(opt, synchronizeRandom);
            const ed = Math.round(performance.now() * 1000);
            toast.info(`单回合速度: ${(ed - st) / 1000}ms`);
        } else if (name === '4ascend-hce') {
            await ai_worker.HCE_RESET(
                0
            );
            await ai_worker.HCE_TURN(xy2index(4, 4, 9));

            const st = Math.round(performance.now() * 1000);
            await ai_worker.HCE_THINK(opt);
            const ed = Math.round(performance.now() * 1000);
            toast.info(`单回合速度: ${(ed - st) / 1000}ms`);
        }
    } catch (error) {
        alert(error.toString());
    }
};

/**
 * @description: 转换难度为具体数值
 * @param {string} name
 * @param {string} opt
 * @return {number}
 */
const ai_level = (name, opt) => {
    if (name === '4ascend-zero') {
        if (opt === '1') return 55;
        else if (opt === '2') return 115;
        else if (opt === '3') return 225;
        else if (opt === '4') return 585;
        else if (opt === '5') return 888;
        else if (opt === '6') return 888;
    } else if (name === '4ascend-hce') {
        if (opt === '1') return 1200;
        else if (opt === '2') return 3400;
        else if (opt === '3') return 5400;
        else if (opt === '4') return 8000;
        else if (opt === '5') return 11000;
    }
};

/** Only the hidden ??? level may inspect the live match RNG state. */
const ai_synchronize_random = (name, opt) => name === '4ascend-zero' && opt === '6';




// 加入房间
button_server_join.addEventListener('pointerdown', (event) => {
    if (event.target !== button_server_join) return;

    const name = select_server_ai.value;
    const opt = select_server_level.value;

    const ai = select_server_ai.value;
    const mode = select_server_mode.value;

    if (!name) return toast.error('请先选择对手！');
    else if (!opt) return toast.error('请先选择难度！');
    // else if (ai === '4ascend-zero' && mode === 'blight') return toast.error('ZERO不支持灾荒游戏模式！');
    else if (ai === '4ascend-hce' && mode === 'normal') return toast.error('HCE不支持普通游戏模式！');
    else if (Number(input_server_health.value) > 10) return toast.error('生命值太大！');

    const archive = input_server_archive.value;
    if (archive !== '' && !ArchiveV0.load(BaseZalgo.decode(archive))) return toast.error('非法对局存档！');

    Ai.setup(
        input_server_archive.value,
        Number(input_server_health.value),
        input_server_board.value,
        select_server_balance.value,
        select_server_mode.value,
        select_server_first.value,
        select_server_color.value,
        select_server_ai.value,
        ai_level(name, select_server_level.value),
        (name === '4ascend-zero' ? 'ZERO' : 'HCE') + `（${select_server_level.selectedOptions[0].textContent}）`,
        ai_synchronize_random(name, select_server_level.value),
        select_server_level.value
    );
    Ai.run();

    button_home.classList.add('d-none');
    window.switch_wection(main_game, main_opt);
});


// 运行测试
button_server_test.addEventListener('pointerdown', (event) => {
    if (event.target !== button_server_test) return;

    const name = select_server_ai.value;
    const opt = select_server_level.value;

    if (!name) return toast.error('请先选择对手！');
    else if (!opt) return toast.error('请先选择难度！');

    window.sleep_task(
        [
            input_server_archive,
            input_server_health,
            // input_server_board,
            select_server_balance,
            select_server_color,
            select_server_first,
            select_server_mode,
            select_server_level,
            select_server_ai,
        ],
        button_server_test,
        async () => ai_test(name, ai_level(name, opt), ai_synchronize_random(name, opt))
    );
});


// 功能面板
game_msg.addEventListener('pointerdown', (event) => {
    if (event.target !== game_msg) return;

    dialog_tools.classList.remove('d-none');
    dialog_tools.show();
});
